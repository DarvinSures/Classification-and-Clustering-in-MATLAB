%readtable
dataCleaned = readtable("datacleanforanntraining.xlsx");

%get summary of table
summary(dataCleaned);

%transpose
dataclean = table2array(dataCleaned);
transposedata = dataclean';

%define inputs and targets columns
inputs = transposedata([1:27],:);
targets = transposedata(28,:);

%Create a Pattern Recognition Network
hiddenLayerSize = 20;
net = patternnet(hiddenLayerSize, 'trainrp');

%Set up Division
net.divideParam.trainRatio = 80/100;
net.divideParam.valRatio = 10/100;
net.divideParam.testRatio = 10/100;

%train network
[net,tr] = train(net,inputs,targets);

%Test the network
outputs = net(inputs);
errors = gsubtract(targets,outputs);
performance = perform(net,targets,outputs);

%View the network
view(net);

% Compute AUROC 
[X,Y,T,AUC] = perfcurve(targets,outputs,1);
AUC

% plot ROC
figure, plotroc(targets,outputs);

%Plots figures, uncomment to show plots
%figure, plotperform(tr)
%figure, plottrainstate(tr)
%figure, ploterrhist(errors)
%figure, plotroc(targets, outputs)
%figure, plotconfusion(targets, outputs)




