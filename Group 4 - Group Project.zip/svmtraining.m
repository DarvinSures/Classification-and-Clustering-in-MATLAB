%read table
dataCleanedtable = readtable('dataCleanedtable.csv');
%%
%%define inputs and targets columns
x = dataCleanedtable(:,1:27);
y = dataCleanedtable(:,28);
%%
%input random permutations which is equal to number of rows
%xtr and ytr are training data sets
%80% = training
rand = randperm(70434);
xtr = x(rand(1:56347),:);
ytr = y(rand(1:56347),:);

%%
%testing dataset
% 20% = rest
xt = x(rand(56348:70434),:);
yt = y(rand(56348:70434),:);
%%
%linear
SVMModel = fitcsvm(xtr,ytr,'Standardize',true,...
    'KernelScale','auto');
SVMModel.KernelParameters
%prior probability
SVMModel.Prior
%%
%determine out-of-sample misclassification rate by using 10-fold cross validation.
CVSVMModel = crossval(SVMModel);
CVSVMModel
classLoss = kfoldLoss(CVSVMModel);
%look at this value
classLoss

%%
%gaussian 
SVMModelg = fitcsvm(X,Y,'Standardize',true,'KernelFunction','RBF',...
    'KernelScale','auto');
SVMModelg.KernelParameters
%prior probability
SVMModelg.Prior
%%
%determine out-of-sample misclassification rate by using 10-fold cross validation.
CVSVMModelg = crossval(SVMModelg);
CVSVMModelg

classLossg = kfoldLoss(CVSVMModelg);
%look at this value
classLossg

%%
%which ever model (linear og gaussian provide lesser classloss is used.
%example below is using linear
%test model accuracy
result = predict(SVMModel, xt);
yt = table2array(yt);
accuracy = sum(result == yt)/length(yt)*100;
sp = sprintf("Test accuracy = %.2f", accuracy);
disp(sp)
%%
%confusion matrix
cm = confusionchart(yt,result);
cm
%%
%auc
[X,Y,T,AUC] = perfcurve(yt,result,1);
AUC
%roc
plot(X,Y)
xlabel('False positive rate') 
ylabel('True positive rate')
title('ROC for Classification by SVM')