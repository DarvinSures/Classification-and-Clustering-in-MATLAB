load DataCleaning

%categorize variables first
dataCleaned.race = findgroups (dataCleaned.race);
dataCleaned.gender = findgroups (dataCleaned.gender);
dataCleaned.age = findgroups (dataCleaned.age);
dataCleaned.admission_type_id = findgroups (dataCleaned.admission_type_id);
dataCleaned.change = findgroups (dataCleaned.change);
dataCleaned.diabetesMed = findgroups (dataCleaned.diabetesMed);
dataCleaned.readmitted = findgroups (dataCleaned.readmitted);

dataCleaned.race = double(dataCleaned.race);
dataCleaned.gender = double(dataCleaned.gender);
dataCleaned.age  = double(dataCleaned.age);
dataCleaned.admission_type_id = double(dataCleaned.admission_type_id);
dataCleaned.discharge_disposition_id = double(dataCleaned.discharge_disposition_id) ;
dataCleaned.admission_source_id = double(dataCleaned.admission_source_id);
dataCleaned.time_in_hospital = double(dataCleaned.time_in_hospital);
dataCleaned.num_lab_procedures = double(dataCleaned.num_lab_procedures);
dataCleaned.num_procedures = double(dataCleaned.num_procedures);
dataCleaned.num_medications = double(dataCleaned.num_medications);
dataCleaned.diag_1 = double(dataCleaned.diag_1);
dataCleaned.diag_2 = double(dataCleaned.diag_2);
dataCleaned.diag_3 = double(dataCleaned.diag_3);
dataCleaned.number_diagnoses = double(dataCleaned.number_diagnoses);
dataCleaned.max_glu_serum = double(dataCleaned.max_glu_serum);
dataCleaned.A1Cresult = double(dataCleaned.A1Cresult);
dataCleaned.metformin = double(dataCleaned.metformin);
dataCleaned.repaglinide = double(dataCleaned.repaglinide);
dataCleaned.nateglinide = double(dataCleaned.nateglinide);
dataCleaned.glimepiride = double(dataCleaned.glimepiride);
dataCleaned.glipizide = double(dataCleaned.glipizide);
dataCleaned.glyburide = double(dataCleaned.glyburide);
dataCleaned.pioglitazone = double(dataCleaned.pioglitazone);
dataCleaned.rosiglitazone = double(dataCleaned.rosiglitazone);
dataCleaned.insulin = double(dataCleaned.insulin);
dataCleaned.change = double(dataCleaned.change);
dataCleaned.diabetesMed = double(dataCleaned.diabetesMed);
dataCleaned.readmitted = double(dataCleaned.readmitted);

% Inputs and Targets
dataclean = table2array(dataCleaned);
x = dataclean(:,1:27);
y = dataclean(:,28);
%%
% create training and testing datasets
rand = randperm(70434);
%training dataset
tr_x = x(rand(1:56347),:);
tr_y = y(rand(1:56347),:);

%testing dataset
t_x = x(rand(56348:70434),:);
t_y = y(rand(56348:70434),:);

%% cross validation
c = cvpartition(tr_y,'KFold',10,'Stratify',true)


%% forward feature selection
% to select the best features 
opts = statset('display','iter')
[fs,history] = sequentialfs(@(tr_data, tr_labels, t_data, t_labels)...
    sum(predict(fitcensemble(tr_data,tr_labels),t_data) ~= t_labels), ...
    tr_x,tr_y,'cv',c,'options',opts,'nfeatures',10)

%%
% Search for best t_x 
t_x_best = t_x(:,fs);

%%
%Train Classification Ensemble
RF = fitcensemble(t_x_best,t_y)

%%
% Compute prediction from t_x and the model
prediction = predict(RF,t_x_best) 
%%
% Compute accuracy 
accuracy = sum((predict(RF,t_x_best) == t_y))/length(t_y)*100

%%
% Plot confusion matrix
cm = confusionchart(t_y,prediction)

%%
%Compute AUC and plot ROC curve
[X,Y,T,AUC] = perfcurve(t_y,prediction,1);
AUC
plot(X,Y)
xlabel('False positive rate') 
ylabel('True positive rate')
title('ROC for Classification by Random Forest')